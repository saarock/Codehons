import styles from './Services.module.css';
import { BsBackpack2Fill } from "react-icons/bs";
import { BsAwardFill } from "react-icons/bs";
export default function Services() {
    return (
        <>
            <div className={styles.services} id="services">
                <div className={styles.all_services}>

                    <div id="mid">


                        <div className={styles.top}>
                            <h3>MY SERIVCE</h3>
                        </div>

                        <div className={styles.middle}>
                            <h2>Crafting stories through <br />
                                design and innovation</h2>
                        </div>
                        <div className={styles.bottom}>

                            <div className={styles.bottom_left}>
                                <div className={styles.icon}>
                                    <BsBackpack2Fill />
                                </div>
                                <div className={styles.what}>
                                    <h3>Fullstack (Node python)</h3>
                                </div>

                                <div className={styles.describe}>
                                    <p>
                                        Nemo design enim ipsam voluptatem quim voluptas sit aspernaturaut odit auting
                                        fugit sed thisnqui
                                        a consequuntur magni doloreseos designer heresm qui
                                    </p>
                                </div>

                            </div>
                            <div className={styles.bottom_middle}>

                                <div className={styles.icon}>
                                    <BsBackpack2Fill />
                                </div>
                                <div className={styles.what}>
                                    <h3>Web Desing</h3>
                                </div>

                                <div className={styles.describe}>
                                    <p>
                                        Nemo design enim ipsam voluptatem quim voluptas sit aspernaturaut odit auting
                                        fugit sed thisnqui
                                        a consequuntur magni doloreseos designer heresm qui
                                    </p>
                                </div>
                            </div>
                            <div className={styles.bottom_right}>
                                <div className={styles.icon}>
                                    <BsAwardFill />
                                </div>
                                <div className={styles.what}>
                                    <h3>Web Desing</h3>
                                </div>

                                <div className={styles.describe}>
                                    <p>
                                        Nemo design enim ipsam voluptatem quim voluptas sit aspernaturaut odit auting
                                        fugit sed thisnqui
                                        a consequuntur magni doloreseos designer heresm qui
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}